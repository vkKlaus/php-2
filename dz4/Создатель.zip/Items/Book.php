<?php

class Book extends Item
{
}
