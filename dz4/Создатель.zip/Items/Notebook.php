<?php

class Notebook extends Item
{
}
