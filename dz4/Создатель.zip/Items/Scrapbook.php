<?php

class Scrapbook extends Item
{
}
