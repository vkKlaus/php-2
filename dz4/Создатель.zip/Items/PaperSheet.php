<?php

class PaperSheet extends Item
{
}
