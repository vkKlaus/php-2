<?php

class Scissors extends Item
{
}
