<?php

class Pen extends Item
{
}
