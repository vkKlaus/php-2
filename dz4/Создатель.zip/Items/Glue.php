<?php

class Glue extends Item
{
}
