<?php

class Ruler extends Item
{
}
