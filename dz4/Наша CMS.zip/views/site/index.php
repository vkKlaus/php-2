<?php include ROOT . '/views/layouts/header.php'; ?>
    <h1>Это главная страница</h1>
<?php include ROOT . '/views/layouts/footer.php'; ?>