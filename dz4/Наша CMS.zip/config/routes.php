<?php

return array(
    'about' => 'site/about',
    'index' => 'site/index', 
    '' => 'site/index',
);
