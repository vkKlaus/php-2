<?php 

class Format_4
{
    public $name = 'класс не имеет интерфейс Formatter, и не имеет метод format';
}