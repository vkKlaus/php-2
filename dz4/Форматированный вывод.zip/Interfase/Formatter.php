<?php

interface Formatter 
{
    public function format($string);
}