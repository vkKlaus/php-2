<?php

abstract class Instrument
{
    public function location($item)
    {
        return "Убрал $item внутрь стола";
    }
}
