<?php

abstract class Papers
{
    public function location($item)
    {
        return "Положил $item на стол";
    }
}
