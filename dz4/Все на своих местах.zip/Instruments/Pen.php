<?php

class Pen extends Instrument
{
}
