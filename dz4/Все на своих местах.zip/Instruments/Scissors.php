<?php

class Scissors extends Instrument
{
}
