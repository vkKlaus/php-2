<?php

class Glue extends Instrument
{
}
