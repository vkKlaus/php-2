<?php

class Ruler extends Instrument
{
}
