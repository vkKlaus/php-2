<?php

class Scrapbook extends Papers
{
}
