<?php

class Book extends Papers
{
}
