<?php

class Notebook extends Papers
{
}
