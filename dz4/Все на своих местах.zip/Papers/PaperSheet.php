<?php

class PaperSheet extends Papers
{
}
