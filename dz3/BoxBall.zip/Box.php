<?php

class Box
{
    public function putBall(Ball $ball){
        echo 'В корзину добавлен мяч' .PHP_EOL;
    }
}