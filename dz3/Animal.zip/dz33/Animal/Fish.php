<?php

class Fish extends Animal
{
    public function move()
    {
        return 'буль-буль';
    }
}