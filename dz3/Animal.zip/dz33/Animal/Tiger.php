<?php

class Tiger extends Animal
{
    public function move()
    {
        return 'т-о-о-о-о-п т-о-о-о-о-п';
    }
}