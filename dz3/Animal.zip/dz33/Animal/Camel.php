<?php

class Camel extends Animal
{
    public function move()
    {
        return 'шлеп - шлеп';
    }
}
