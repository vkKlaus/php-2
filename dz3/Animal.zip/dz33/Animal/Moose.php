<?php

class Moose extends Animal
{
    public function move()
    {
        return 'хряп-бум';
    }
}