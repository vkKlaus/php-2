<?php

class Bear extends Animal
{
    public function move()
    {
        return 'ТОП-ТОП';
    }
}
