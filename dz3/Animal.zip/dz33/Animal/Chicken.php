<?php

class Chicken extends Animal
{
    public function move()
    {
        return 'вжих-вжих - топ-топ';
    }
}