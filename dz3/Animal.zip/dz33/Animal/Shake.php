<?php

class Shake extends Animal
{
    public function move()
    {
        return 'шшшшшшшшшшшшшшшшшшшшшшшшшшшш';
    }
}