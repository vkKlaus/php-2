<?php

abstract class Creature
{
    
}