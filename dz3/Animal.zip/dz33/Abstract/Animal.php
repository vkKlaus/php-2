<?php

abstract class Animal extends Creature
{
    abstract public function move();
}