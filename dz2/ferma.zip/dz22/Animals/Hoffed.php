<?php 

abstract class Hoffed extends Animal
{
    
}