<?php

class BlueFlame
{
    public function render($name)
    {
        return $name . " голубое пламя" . PHP_EOL;
    }
}
