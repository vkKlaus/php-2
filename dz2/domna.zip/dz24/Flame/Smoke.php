<?php

class Smoke
{
    public function render($name)
    {
        return $name . " лишь задымился" . PHP_EOL;
    }
}
