<?php

class RedFlame
{
    public function render($name)
    {
        return $name . " красное пламя" . PHP_EOL;
    }
}