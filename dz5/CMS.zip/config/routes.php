<?php

return array(
    'exeption'=>'site/exeption',
    'about' => 'site/about',
    'index' => 'site/index', 
    '' => 'site/index',
);
