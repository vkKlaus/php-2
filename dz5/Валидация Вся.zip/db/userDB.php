<?php
return [
'user1@email.com' => [
'id'=>0,
'name'=>'user1',
'age'=>20,
],
'user2@email.com' => [
'id'=>1,
'name'=>'user2',
'age'=>20,
],
'user3@email.com' => [
'id'=>2,
'name'=>'user3',
'age'=>20,
],
'user4@email.com' => [
'id'=>3,
'name'=>'user4',
'age'=>20,
],
'user5@email.com' => [
'id'=>4,
'name'=>'user5',
'age'=>20,
],
'user6@email.com' => [
'id'=>5,
'name'=>'user6',
'age'=>20,
],
'user7@email.com' => [
'id'=>6,
'name'=>'user7',
'age'=>20,
],
'user8@email.com' => [
'id'=>7,
'name'=>'user8',
'age'=>20,
],
'user9@email.com' => [
'id'=>8,
'name'=>'user9',
'age'=>20,
],
'user10@email.com' => [
'id'=>9,
'name'=>'user10',
'age'=>20,
],
'gfhfgh@eee.ee' => [
'id'=>10,
'name'=>'wdfwedfwe',
'age'=>19,
],
'asasdfasdf@ddd.rr' => [
'id'=>11,
'name'=>'sdcwd',
'age'=>345,
],
'asd@amd.ru' => [
'id'=>12,
'name'=>'ауу',
'age'=>45,
],
'sdfsdfsfsfsfsfsf@ddd.rr' => [
'id'=>13,
'name'=>'trytyeryerytr',
'age'=>56,
],
];