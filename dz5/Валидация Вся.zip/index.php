<?php
require $_SERVER['DOCUMENT_ROOT'] . '/module/RequestDB.php';
require $_SERVER['DOCUMENT_ROOT'] . '/module/UserFormValidator.php';
require $_SERVER['DOCUMENT_ROOT'] . '/module/User.php';
require $_SERVER['DOCUMENT_ROOT'] . '/views/form.php';


